# -*- coding: utf-8 -*-
from __future__ import unicode_literals
from django.utils.timezone import get_current_timezone
from datetime import datetime, date
from time import strptime, localtime, strftime
from django.shortcuts import render, HttpResponse, redirect
from django.contrib import messages
from models import *
import bcrypt
# Create your views here.
def register(request):
    errors = User.objects.basic_validator(request.POST)
    if len(errors):
        for tag, error in errors.iteritems():
            messages.error(request, error, extra_tags=tag)
            print errors
        return redirect("/")
    else:
        pw = request.POST["password"]
        hash1 = bcrypt.hashpw(pw.encode(), bcrypt.gensalt())
        b = User.objects.create(name=request.POST["name"], email=request.POST["email"], password=hash1)
        #above created a user, and stored it in a variable called b
        request.session["user_id"] = b.id #stored the user id in session
        request.session["name"] = b.name
    return redirect("/appointments")

def login(request):
    errors = User.objects.login_validator(request.POST)
    print errors
    if len(errors):
        for tag, error in errors.iteritems():
            messages.error(request, error, extra_tags=tag)
            print errors
        return redirect("/")
    else:
        user = User.objects.get(email = request.POST["email"]) #get the user based on their email. This could be any column in the User table
        request.session["user_id"] = user.id #store user id in session
        request.session['name'] = user.name
        return redirect("/appointments")

def index(request):
    return render(request,'index.html')

def add(request):
    errors = Appointment.objects.add_validator(request.POST)
    if len(errors):
        for tag, error in errors.iteritems():
            messages.error(request, error, extra_tags=tag)
        return redirect("/appointments")
    else:
        a = User.objects.get(name=request.session['name'])
        time = datetime.strptime(request.POST["time"], "%H:%M")
        Appointment.objects.create(taskdate=request.POST["taskdate"], tasks=request.POST["tasks"], time=time, user = a)
        return redirect("/appointments")

def appointments(request):
    c = User.objects.get(id=request.session["user_id"])

    context = {
        "my_tasks" : Appointment.objects.filter(user = c, taskdate = date.today()),
        "other_appointments" : Appointment.objects.filter(user = c).exclude(taskdate=date.today()),
        "testsort" : Appointment.objects.order_by("taskdate")
    }
    return render(request, 'appointments.html', context)

def delete_appt(request, id):
    a = Appointment.objects.get(id=id)
    a.delete()
    return redirect('/appointments')

def edit_appt(request, id):
    context = {
        "task_id" : Appointment.objects.get(id=id),
        }
    print context
    return render(request, 'edit.html', context)

def save_appointments(request, id):
    errors = Appointment.objects.add_validator(request.POST)
    if len(errors):
        for tag, error in errors.iteritems():
            messages.error(request, error, extra_tags=tag)
        return redirect("/edit/" + id)
    else:
        # a = User.objects.get(name=request.session['name'])
        time = datetime.strptime(request.POST["time"], "%H:%M")
        u = Appointment.objects.get(id=id)
        u.taskdate = request.POST["taskdate"]
        u.time = time
        u.tasks = request.POST["tasks"]
        u.save()
        return redirect("/appointments")

def logoutfunc(request): #dome we need a seperate function and url for the logout method
    request.session.flush()
    return redirect('/logout')

def logout(request): #dome
    return render(request,'index.html')
