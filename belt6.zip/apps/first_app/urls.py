from django.conf.urls import url
from . import views


urlpatterns = [
    url(r'^$', views.index),
    url(r'^register$',views.register),
    url(r'^login$', views.login),
    url(r'^logout$', views.logout), #render the logout page
    url(r'^logoutfunc$', views.logoutfunc), #process the logic .
    url(r'^appointments$', views.appointments),
    url(r'^edit/(?P<id>\d+)$',views.edit_appt),
    url(r'^delete_appt/(?P<id>\d+)$', views.delete_appt),
    url(r'^add$', views.add),
    url(r'^save_appointments/(?P<id>\d+)$', views.save_appointments)


]
